import 'package:flutter/material.dart';

void main() {
  runApp(const ScrollLoop());
}

class ScrollLoop extends StatefulWidget {
  const ScrollLoop({Key? key}) : super(key: key);

  @override
  _ScrollLoopState createState() => _ScrollLoopState();
}

class _ScrollLoopState extends State<ScrollLoop> {
  ScrollController _controller = ScrollController();

  /// [_list] is growable and holds the assets which will scroll.
  List<String> _list = [
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    "https://www.cpx-research.com/main/en/assets/img/logo.svg",
    // Add your other URLs here
  ];

  @override
  void initState() {
    _controller.addListener(() {
      if (_controller.position.pixels == _controller.position.maxScrollExtent) {
        _controller.jumpTo(_controller.position.minScrollExtent);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startScroll();
    });

    super.initState();
  }

  void _startScroll() {
    _controller
        .animateTo(
      _controller.position.maxScrollExtent,
      duration: Duration(
          milliseconds: 4000), // تعديل هذه القيمة لزيادة أو تقليل سرعة الحركة
      curve: Curves.linear,
    )
        .whenComplete(() {
      _controller.jumpTo(_controller.position.minScrollExtent);
      _startScroll(); // يبدأ التمرير من جديد بمجرد الانتهاء
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final _size = MediaQuery.of(context).size;
    return MaterialApp(
      home: Directionality(
        textDirection: TextDirection.ltr,
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    controller: _controller,
                    scrollDirection: Axis.horizontal,
                    itemCount: _list.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: _size.width / 4,
                          height: _size.height / 10,
                          child: Image.network(_list[index]),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
